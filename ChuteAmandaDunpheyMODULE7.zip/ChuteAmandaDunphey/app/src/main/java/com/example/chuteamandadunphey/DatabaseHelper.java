package com.example.chuteamandadunphey;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "chute_inventory.db";
    private static final int DB_VERSION = 1;

    // USERS
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "user_id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

    // INVENTORY
    public static final String TABLE_INVENTORY = "inventory";
    public static final String COL_ITEM_ID = "item_id";
    public static final String COL_ITEM_NAME = "name";
    public static final String COL_ITEM_QTY = "quantity";
    public static final String COL_ITEM_UPDATED_AT = "updated_at";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsers = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT NOT NULL UNIQUE, " +
                COL_PASSWORD + " TEXT NOT NULL" +
                ");";

        String createInventory = "CREATE TABLE " + TABLE_INVENTORY + " (" +
                COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_ITEM_NAME + " TEXT NOT NULL, " +
                COL_ITEM_QTY + " INTEGER NOT NULL, " +
                COL_ITEM_UPDATED_AT + " INTEGER NOT NULL" +
                ");";

        db.execSQL(createUsers);
        db.execSQL(createInventory);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        onCreate(db);
    }

    public boolean createUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_USERNAME, username.trim());
        cv.put(COL_PASSWORD, password);

        try {
            long result = db.insertOrThrow(TABLE_USERS, null, cv);
            return result != -1;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean validateLogin(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();

        Cursor c = db.query(
                TABLE_USERS,
                new String[]{COL_USER_ID},
                COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username.trim(), password},
                null, null, null
        );

        boolean ok = (c != null && c.moveToFirst());
        if (c != null) c.close();
        return ok;
    }


    public long addItem(String name, int qty) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_ITEM_NAME, name.trim());
        cv.put(COL_ITEM_QTY, qty);
        cv.put(COL_ITEM_UPDATED_AT, System.currentTimeMillis());
        return db.insert(TABLE_INVENTORY, null, cv);
    }

    public Cursor getAllItems() {
        SQLiteDatabase db = getReadableDatabase();
        return db.query(
                TABLE_INVENTORY,
                new String[]{COL_ITEM_ID, COL_ITEM_NAME, COL_ITEM_QTY, COL_ITEM_UPDATED_AT},
                null, null, null, null,
                COL_ITEM_UPDATED_AT + " DESC"
        );
    }

    public boolean updateItem(long id, String name, int qty) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_ITEM_NAME, name.trim());
        cv.put(COL_ITEM_QTY, qty);
        cv.put(COL_ITEM_UPDATED_AT, System.currentTimeMillis());

        int rows = db.update(TABLE_INVENTORY, cv, COL_ITEM_ID + "=?", new String[]{String.valueOf(id)});
        return rows > 0;
    }

    public boolean deleteItem(long id) {
        SQLiteDatabase db = getWritableDatabase();
        int rows = db.delete(TABLE_INVENTORY, COL_ITEM_ID + "=?", new String[]{String.valueOf(id)});
        return rows > 0;
    }
}