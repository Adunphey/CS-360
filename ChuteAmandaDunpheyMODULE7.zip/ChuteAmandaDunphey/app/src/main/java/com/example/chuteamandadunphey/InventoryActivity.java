package com.example.chuteamandadunphey;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class InventoryActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private LinearLayout listContainer;
    private boolean smsEnabled = false;

    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                smsEnabled = granted;
                Toast.makeText(
                        this,
                        granted ? "SMS enabled." : "SMS not enabled (app still works).",
                        Toast.LENGTH_SHORT
                ).show();
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        db = new DatabaseHelper(this);

        Button btnEnableSms = findViewById(R.id.btnEnableSms);
        Button btnAddItem = findViewById(R.id.btnAddItem);
        listContainer = findViewById(R.id.listContainer);

        btnEnableSms.setOnClickListener(v -> enableSmsFlow());
        btnAddItem.setOnClickListener(v -> showAddDialog());

        refreshList();
    }

    private void enableSmsFlow() {
        boolean granted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;

        if (granted) {
            smsEnabled = true;
            Toast.makeText(this, "SMS already enabled.", Toast.LENGTH_SHORT).show();
        } else {
            smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        }
    }

    private void showAddDialog() {
        EditText etName = new EditText(this);
        etName.setHint("Item name");

        EditText etQty = new EditText(this);
        etQty.setHint("Quantity");
        etQty.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 20, 40, 10);
        layout.addView(etName);
        layout.addView(etQty);

        new AlertDialog.Builder(this)
                .setTitle("Add Item")
                .setView(layout)
                .setPositiveButton("Save", (d, which) -> {
                    String name = etName.getText().toString().trim();
                    Integer qty = parseIntSafe(etQty.getText().toString().trim());

                    if (name.isEmpty() || qty == null) {
                        Toast.makeText(this, "Enter name and quantity.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    db.addItem(name, qty);
                    refreshList();

                    if (qty <= 3) sendLowStockSmsIfAllowed(name, qty);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showUpdateDialog(long id, String currentName, int currentQty) {
        EditText etName = new EditText(this);
        etName.setHint("Item name");
        etName.setText(currentName);

        EditText etQty = new EditText(this);
        etQty.setHint("Quantity");
        etQty.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        etQty.setText(String.valueOf(currentQty));

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 20, 40, 10);
        layout.addView(etName);
        layout.addView(etQty);

        new AlertDialog.Builder(this)
                .setTitle("Update Item")
                .setView(layout)
                .setPositiveButton("Update", (d, which) -> {
                    String name = etName.getText().toString().trim();
                    Integer qty = parseIntSafe(etQty.getText().toString().trim());

                    if (name.isEmpty() || qty == null) {
                        Toast.makeText(this, "Enter name and quantity.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    db.updateItem(id, name, qty);
                    refreshList();

                    if (qty <= 3) sendLowStockSmsIfAllowed(name, qty);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void refreshList() {
        listContainer.removeAllViews();

        Cursor c = db.getAllItems();
        while (c.moveToNext()) {
            long id = c.getLong(c.getColumnIndexOrThrow(DatabaseHelper.COL_ITEM_ID));
            String name = c.getString(c.getColumnIndexOrThrow(DatabaseHelper.COL_ITEM_NAME));
            int qty = c.getInt(c.getColumnIndexOrThrow(DatabaseHelper.COL_ITEM_QTY));

            Button row = new Button(this);
            row.setText(name + " (Qty: " + qty + ")\nTap = Update | Long press = Delete");

            // Update
            row.setOnClickListener(v -> showUpdateDialog(id, name, qty));

            // delete
            row.setOnLongClickListener(v -> {
                db.deleteItem(id);
                refreshList();
                Toast.makeText(this, "Deleted: " + name, Toast.LENGTH_SHORT).show();
                return true;
            });

            listContainer.addView(row);
        }
        c.close();
    }

    private void sendLowStockSmsIfAllowed(String itemName, int qty) {
        if (!smsEnabled) {
            Toast.makeText(this, "Low stock detected (SMS disabled).", Toast.LENGTH_SHORT).show();
            return;
        }

        // Put YOUR number here for testing
        String phoneNumber = "5551234567";
        String msg = "Chute Alert: '" + itemName + "' is low (qty=" + qty + ").";

        try {
            SmsManager.getDefault().sendTextMessage(phoneNumber, null, msg, null, null);
            Toast.makeText(this, "SMS sent.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private Integer parseIntSafe(String s) {
        try { return Integer.parseInt(s); }
        catch (Exception e) { return null; }
    }
}